#include <iostream>
#include <stdio.h>
using namespace std;
int main(){
	freopen("Hello","rt",stdin);
  long long Print,Past,rest,count,x=1;
  while(cin>>Print){
                    if(Print<0)break;
                    rest=0;
                    count=0;
                    Past=1;
                    while(Print!=Past){
                    rest=Print-Past;
                    if(rest>Past){
                                  Past+=Past;
                                  count++;
                                  }
                    else {
                                  Past+=rest;
                                  rest=0;
                                  count++;
                                  }
                    }
   cout<<"Case "<<x<<": "<<count<<endl;
   x++;
}
   return 0;
}
