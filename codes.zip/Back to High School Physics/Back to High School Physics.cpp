#include <iostream>
#include <stdio.h>
using namespace std;
int main(){
	freopen("physics","rt",stdin);
long int V,T,space;
while(cin>>V){
              cin>>T;
              space=V*(2*T);
              cout<<space<<endl;
}
	return 0;
}
